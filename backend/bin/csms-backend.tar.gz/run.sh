#!/bin/bash
cd "$(dirname $0)"
echo "Starting CSMS Backend..."
exec ./bin/csms-backend
